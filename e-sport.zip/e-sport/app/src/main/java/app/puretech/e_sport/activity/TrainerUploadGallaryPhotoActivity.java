package app.puretech.e_sport.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.IOException;
import java.util.List;

import app.puretech.e_sport.App;
import app.puretech.e_sport.R;
import app.puretech.e_sport.utill.PermissionUtility;
import okhttp3.MultipartBody;

import static java.security.AccessController.getContext;

public class TrainerUploadGallaryPhotoActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnUploadImage, btnSelectImage;
    public static int REQUEST_CODE_GALLERY_PROFILE_PROFILE = 1002;
    public static int REQUEST_CODE_CAMERA_PROFILE_PROFILE = 1003;
    String userChoosenTask;
    ImageView imgUpload;
    Intent iback;
    App app;
    Activity activity;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainer_upload_gallary_photo);


        /* find out id's of all widgets*/
        initWidget();

        btnUploadImage.setOnClickListener(this);
        btnSelectImage.setOnClickListener(this);

    }

    private void initWidget() {
        app = (App) getApplication();
        activity = this;
        btnSelectImage = findViewById(R.id.btn_select_photo);
        btnUploadImage = findViewById(R.id.btn_upload_gallary);
        imgUpload = findViewById(R.id.img_trainer_gallary_upload);
        iback = new Intent(activity, TrainerGalleryActivity.class);
        toolbar = findViewById(R.id.toolbar_trainer_upload_gallary);

        doBack(toolbar);
    }

    private void doBack(Toolbar toolbar) {
        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.startActivity(iback);
                activity.finish();
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_select_photo:
                requestStoragePermission();
                break;
        }
    }

    private void requestStoragePermission() {
        Dexter.withActivity(TrainerUploadGallaryPhotoActivity.this)
                .withPermissions(
                        Manifest.permission.CAMERA,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            //   openImageChooser();
                            selectImage(REQUEST_CODE_CAMERA_PROFILE_PROFILE, REQUEST_CODE_GALLERY_PROFILE_PROFILE);
                            // Toast.makeText(TrainerUploadGallaryPhotoActivity.this, "All permissions are granted!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }

                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(TrainerUploadGallaryPhotoActivity.this, "Error occurred! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    private void selectImage(int request_camera, int request_gallery) {
        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = PermissionUtility.checkPermission(TrainerUploadGallaryPhotoActivity.this);
                boolean result_camera = PermissionUtility.checkPermissionCamera(TrainerUploadGallaryPhotoActivity.this);
                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    if (result_camera) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, request_camera);
                    }
                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask = "Choose from Library";
                    if (result) {
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);//
                        startActivityForResult(Intent.createChooser(intent, "Select File"), request_gallery);
                    }
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(TrainerUploadGallaryPhotoActivity.this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", TrainerUploadGallaryPhotoActivity.this.getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap;
        //======================= for camera Profile ===========================================
        if (requestCode == REQUEST_CODE_CAMERA_PROFILE_PROFILE) {

            if (data != null) {
                bitmap = (Bitmap) data.getExtras().get("data");
                imgUpload.setImageBitmap(bitmap);
            } else {
                Toast.makeText(this, "Please, select photo!", Toast.LENGTH_SHORT).show();
            }

        } else if (requestCode == REQUEST_CODE_GALLERY_PROFILE_PROFILE) {
            onSelectFromGalleryResult(data, REQUEST_CODE_GALLERY_PROFILE_PROFILE);
        }
    }

    private void onSelectFromGalleryResult(Intent data, int requestCodeGalleryProfileProfile) {
        Bitmap bm = null;
        if (data != null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                imgUpload.setImageBitmap(bm);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onBackPressed() {
        activity.startActivity(iback);
        activity.finish();
    }
}
