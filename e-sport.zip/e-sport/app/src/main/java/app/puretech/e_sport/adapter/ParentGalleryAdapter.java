package app.puretech.e_sport.adapter;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import app.puretech.e_sport.R;
import app.puretech.e_sport.model.ParentGalleryDTO;
import app.puretech.e_sport.model.SchoolGalleryDTO;
import app.puretech.e_sport.utill.ImageUtil;

public class ParentGalleryAdapter extends BaseAdapter {

    private List<ParentGalleryDTO> array_list;
    private Activity activity;

    public ParentGalleryAdapter(List<ParentGalleryDTO> array_list, Activity activity) {
        this.array_list = array_list;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return array_list.size();
    }

    @Override
    public Object getItem(int position) {
        return array_list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // inflate the layout for each list row
        if (convertView == null) {
            convertView = LayoutInflater.from(activity).
                    inflate(R.layout.parent_gallery_item, parent, false);
        }
        ImageView iv_image = convertView.findViewById(R.id.iv_trainer_gallery_image);
        ImageUtil.displayImage(iv_image, array_list.get(position).getStr_image(), null);
        return convertView;
    }
}