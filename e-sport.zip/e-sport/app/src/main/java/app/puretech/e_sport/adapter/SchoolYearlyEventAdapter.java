package app.puretech.e_sport.adapter;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import app.puretech.e_sport.R;
import app.puretech.e_sport.model.SchoolYearlyEventDTO;
import app.puretech.e_sport.model.TrainerYearlyEventsDTO;

public class SchoolYearlyEventAdapter extends RecyclerView.Adapter<SchoolYearlyEventAdapter.ViewHolder> {

    private List<SchoolYearlyEventDTO> array_list;
    private Activity activity;

    public SchoolYearlyEventAdapter(List<SchoolYearlyEventDTO> array_list, Activity activity) {
        this.array_list = array_list;
        this.activity = activity;

    }

    @NonNull
    @Override
    public SchoolYearlyEventAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.school_yearly_events_item, viewGroup, false);

        return new SchoolYearlyEventAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SchoolYearlyEventAdapter.ViewHolder viewHolder, int position) {
        viewHolder.tv_date.setText(array_list.get(position).getStr_date());
        viewHolder.tv_sub_event_name.setText(array_list.get(position).getStr_sub_event_name());
        viewHolder.tv_session.setText(array_list.get(position).getStr_session());
        viewHolder.tv_grade.setText(array_list.get(position).getStr_grade());
        viewHolder.tv_day.setText(array_list.get(position).getStr_day());
        viewHolder.tv_time.setText(array_list.get(position).getStr_timing());
        viewHolder.tv_venue.setText(array_list.get(position).getStr_venue());    }

    @Override
    public int getItemCount() {
        return array_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tv_date, tv_sub_event_name, tv_session, tv_grade, tv_day, tv_venue, tv_time;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_date = itemView.findViewById(R.id.tv_trainer_yearly_event_date);
            tv_sub_event_name = itemView.findViewById(R.id.tv_sub_event_name);
            tv_session = itemView.findViewById(R.id.tv_session);
            tv_grade = itemView.findViewById(R.id.tv_grade);
            tv_day = itemView.findViewById(R.id.tv_day);
            tv_venue = itemView.findViewById(R.id.tv_venue);
            tv_time = itemView.findViewById(R.id.tv_time);

        }
    }
}
