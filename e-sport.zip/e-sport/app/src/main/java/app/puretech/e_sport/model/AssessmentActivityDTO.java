package app.puretech.e_sport.model;

public class AssessmentActivityDTO {
    String str_name;
    String str_id;

    public String getStr_id() {
        return str_id;
    }

    public void setStr_id(String str_id) {
        this.str_id = str_id;
    }

    public String getStr_name() {
        return str_name;
    }

    public void setStr_name(String str_name) {
        this.str_name = str_name;
    }
}
