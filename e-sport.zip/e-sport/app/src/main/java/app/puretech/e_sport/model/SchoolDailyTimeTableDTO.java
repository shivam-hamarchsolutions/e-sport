package app.puretech.e_sport.model;

public class SchoolDailyTimeTableDTO {
    String str_grade;
    String str_time;
    String str_class;
    String str_session_name;
    String str_attendance;
    String str_school_name;
    String str_image;
    String str_subject;

    public String getStr_subject() {
        return str_subject;
    }

    public void setStr_subject(String str_subject) {
        this.str_subject = str_subject;
    }

    public String getStr_image() {
        return str_image;
    }

    public void setStr_image(String str_image) {
        this.str_image = str_image;
    }

    public String getStr_school_name() {
        return str_school_name;
    }

    public void setStr_school_name(String str_school_name) {
        this.str_school_name = str_school_name;
    }

    public String getStr_time() {
        return str_time;
    }

    public void setStr_time(String str_time) {
        this.str_time = str_time;
    }

    public String getStr_grade() {
        return str_grade;
    }

    public void setStr_grade(String str_grade) {
        this.str_grade = str_grade;
    }

    public String getStr_class() {
        return str_class;
    }

    public void setStr_class(String str_class) {
        this.str_class = str_class;
    }

    public String getStr_attendance() {
        return str_attendance;
    }

    public void setStr_attendance(String str_attendance) {
        this.str_attendance = str_attendance;
    }

    public String getStr_session_name() {
        return str_session_name;
    }

    public void setStr_session_name(String str_session_name) {
        this.str_session_name = str_session_name;
    }
}
