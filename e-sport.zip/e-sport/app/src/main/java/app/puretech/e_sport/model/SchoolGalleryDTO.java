package app.puretech.e_sport.model;

public class SchoolGalleryDTO {
    private String str_image;

    public String getStr_image() {
        return str_image;
    }

    public void setStr_image(String str_image) {
        this.str_image = str_image;
    }
}
