package app.puretech.e_sport.model;

public class SchoolTrainerLeaveApplicationDTO {
    String str_name;
    String str_sport_name;
    String str_subject;
    String str_start_date;
    String str_end_date;
    String str_note;
    String str_image;

    public String getStr_image() {
        return str_image;
    }

    public void setStr_image(String str_image) {
        this.str_image = str_image;
    }

    public String getStr_note() {
        return str_note;
    }

    public void setStr_note(String str_note) {
        this.str_note = str_note;
    }

    public String getStr_end_date() {
        return str_end_date;
    }

    public void setStr_end_date(String str_end_date) {
        this.str_end_date = str_end_date;
    }

    public String getStr_start_date() {
        return str_start_date;
    }

    public void setStr_start_date(String str_start_date) {
        this.str_start_date = str_start_date;
    }

    public String getStr_subject() {
        return str_subject;
    }

    public void setStr_subject(String str_subject) {
        this.str_subject = str_subject;
    }

    public String getStr_sport_name() {
        return str_sport_name;
    }

    public void setStr_sport_name(String str_sport_name) {
        this.str_sport_name = str_sport_name;
    }

    public String getStr_name() {
        return str_name;
    }

    public void setStr_name(String str_name) {
        this.str_name = str_name;
    }

}
