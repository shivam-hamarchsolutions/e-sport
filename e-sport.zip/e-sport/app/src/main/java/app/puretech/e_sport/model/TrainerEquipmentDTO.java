package app.puretech.e_sport.model;

public class TrainerEquipmentDTO {
    private String str_equipment_name;
    private String str_specifiction;
    private String str_inword_for_month;
    private String str_outward_for_month;
    private String str_discre_for_month;
    private String str_physical_stock;
    private String str_opening_balance;

    public String getStr_opening_balance() {
        return str_opening_balance;
    }

    public void setStr_opening_balance(String str_opening_balance) {
        this.str_opening_balance = str_opening_balance;
    }

    public String getStr_physical_stock() {
        return str_physical_stock;
    }

    public void setStr_physical_stock(String str_physical_stock) {
        this.str_physical_stock = str_physical_stock;
    }

    public String getStr_discre_for_month() {
        return str_discre_for_month;
    }

    public void setStr_discre_for_month(String str_discre_for_month) {
        this.str_discre_for_month = str_discre_for_month;
    }

    public void setStr_inword_for_month(String str_inword_for_month) {
        this.str_inword_for_month = str_inword_for_month;
    }

    public String getStr_inword_for_month() {
        return str_inword_for_month;
    }

    public void setStr_outward_for_month(String str_outward_for_month) {
        this.str_outward_for_month = str_outward_for_month;
    }

    public String getStr_outward_for_month() {
        return str_outward_for_month;
    }

    public String getStr_specifiction() {
        return str_specifiction;
    }

    public void setStr_specifiction(String str_specifiction) {
        this.str_specifiction = str_specifiction;
    }

    public String getStr_equipment_name() {
        return str_equipment_name;
    }

    public void setStr_equipment_name(String str_equipment_name) {
        this.str_equipment_name = str_equipment_name;
    }
}
