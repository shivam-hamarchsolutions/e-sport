package app.puretech.e_sport.model;

public class TrainerMonthlyPlannerSubDTO {
    String title;
    String str_class;
    String str_sport_name;
    String str_image;

    public String getStr_image() {
        return str_image;
    }

    public void setStr_image(String str_image) {
        this.str_image = str_image;
    }

    public String getStr_sport_name() {
        return str_sport_name;
    }

    public void setStr_sport_name(String str_sport_name) {
        this.str_sport_name = str_sport_name;
    }

    public String getStr_class() {
        return str_class;
    }

    public void setStr_class(String str_class) {
        this.str_class = str_class;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
