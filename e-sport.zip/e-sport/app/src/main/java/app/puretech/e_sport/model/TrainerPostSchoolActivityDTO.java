package app.puretech.e_sport.model;

public class TrainerPostSchoolActivityDTO {
    private String str_grade;
    private String str_sport_name;
    private String str_sessions;
    private String str_time;
    private String str_start_date;
    private String str_end_date;
    private String str_days;

    public String getStr_sport_name() {
        return str_sport_name;
    }

    public void setStr_sport_name(String str_sport_name) {
        this.str_sport_name = str_sport_name;
    }

    public String getStr_sessions() {
        return str_sessions;
    }

    public void setStr_sessions(String str_sessions) {
        this.str_sessions = str_sessions;
    }

    public String getStr_end_date() {
        return str_end_date;
    }

    public void setStr_end_date(String str_end_date) {
        this.str_end_date = str_end_date;
    }

    public String getStr_days() {
        return str_days;
    }

    public void setStr_days(String str_days) {
        this.str_days = str_days;
    }

    public String getStr_start_date() {
        return str_start_date;
    }

    public void setStr_start_date(String str_start_date) {
        this.str_start_date = str_start_date;
    }

    public String getStr_time() {
        return str_time;
    }

    public void setStr_time(String str_time) {
        this.str_time = str_time;
    }

    public String getStr_grade() {
        return str_grade;
    }

    public void setStr_grade(String str_grade) {
        this.str_grade = str_grade;
    }
}
