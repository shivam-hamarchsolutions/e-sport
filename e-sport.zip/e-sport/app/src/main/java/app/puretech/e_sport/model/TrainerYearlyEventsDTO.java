package app.puretech.e_sport.model;

public class TrainerYearlyEventsDTO {
    private String str_date;
    private String str_sub_event_name;
    private String str_day;
    private String str_timing;
    private String str_session;
    private String str_venue;
    private String str_grade;

    public String getStr_grade() {
        return str_grade;
    }

    public void setStr_grade(String str_grade) {
        this.str_grade = str_grade;
    }

    public String getStr_venue() {
        return str_venue;
    }

    public void setStr_venue(String str_venue) {
        this.str_venue = str_venue;
    }

    public String getStr_session() {
        return str_session;
    }

    public void setStr_session(String str_session) {
        this.str_session = str_session;
    }

    public String getStr_timing() {
        return str_timing;
    }

    public void setStr_timing(String str_timing) {
        this.str_timing = str_timing;
    }

    public String getStr_day() {
        return str_day;
    }

    public void setStr_day(String str_day) {
        this.str_day = str_day;
    }

    public String getStr_sub_event_name() {
        return str_sub_event_name;
    }

    public void setStr_sub_event_name(String str_sub_event_name) {
        this.str_sub_event_name = str_sub_event_name;
    }

    public String getStr_date() {
        return str_date;
    }

    public void setStr_date(String str_date) {
        this.str_date = str_date;
    }
}
