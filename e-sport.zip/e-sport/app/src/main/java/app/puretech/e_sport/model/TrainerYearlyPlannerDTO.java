package app.puretech.e_sport.model;

public class TrainerYearlyPlannerDTO {
    String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
