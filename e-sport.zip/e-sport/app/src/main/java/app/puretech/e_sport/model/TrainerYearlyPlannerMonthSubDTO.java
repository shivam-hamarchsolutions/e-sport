package app.puretech.e_sport.model;

public class TrainerYearlyPlannerMonthSubDTO {
    String title;
    String str_sprot_name;

    public String getStr_sprot_name() {
        return str_sprot_name;
    }

    public void setStr_sprot_name(String str_sprot_name) {
        this.str_sprot_name = str_sprot_name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
