package app.puretech.e_sport.utill;

/**
 * Created by dinesh on 14-02-2018.
 */

public class DataManager {

    public static String status = "";
    public static String message = "";
    public static String url = "http://puretechproject.com/esport_api/api/";
    public static String PROJECT_NUMBER = "244213067806";  // GCM Project number
    public static String urlSchoolPic = "http://puretechproject.com/esport/public/school_pic/";
    public static String urlTrainerPic = "http://puretechproject.com/esport/public/profile_pic/";

}