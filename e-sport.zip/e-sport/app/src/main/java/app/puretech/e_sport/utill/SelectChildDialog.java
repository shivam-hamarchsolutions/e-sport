package app.puretech.e_sport.utill;

import android.app.Activity;
import android.app.Dialog;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import app.puretech.e_sport.App;
import app.puretech.e_sport.R;
import app.puretech.e_sport.adapter.SchoolAchievementsAdapter;
import app.puretech.e_sport.adapter.SelectChildAdapter;
import app.puretech.e_sport.model.SchoolAchievementsDTO;
import app.puretech.e_sport.model.SelectChildDTO;
import retrofit.Callback;
import retrofit.Response;
import retrofit.Retrofit;

public class SelectChildDialog {
    public void selectChildDialog(Activity activity, ArrayList<SelectChildDTO> arrayList) {
        Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.parent_child_dialog);
        final SelectChildAdapter selectChildAdapter;
        final RecyclerView rv_no_of_child = dialog.findViewById(R.id.rv_no_of_child);
        selectChildAdapter = new SelectChildAdapter(arrayList, activity);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(activity);
        rv_no_of_child.setLayoutManager(mLayoutManager);
        rv_no_of_child.setItemAnimator(new DefaultItemAnimator());
        rv_no_of_child.setAdapter(selectChildAdapter);
        dialog.show();
    }

}
